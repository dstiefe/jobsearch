﻿

/// <reference path="angular.min.js" />  

var app;

(function () {
    app = angular.module("JobSearch", []);
})();